package com.example.talabateytraining;
import android.app.*;import android.os.*;import android.graphics.Color;import android.graphics.Typeface;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.content.Context;import android.widget.*;import java.util.*;
public class MainActivity extends Activity{
 Random r=new Random();String[] words={"واحد","اثنين","ثلاثة","أربعة","خمسة","ستة","سبعة","ثمانية","تسعة"};int target,errors=0;long started;boolean active=false;ArrayList<Long> times=new ArrayList<>();
 TextView status,word,last,avg,err,price;EditText input;LinearLayout order,entry;
 GradientDrawable shape(int c,int rad){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(rad);return d;}
 TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(17);t.setPadding(8,8,8,8);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff0d0f12);getWindow().setNavigationBarColor(0xff0d0f12);
 LinearLayout root=col();root.setPadding(18,20,18,18);root.setBackgroundColor(0xff0d0f12);setContentView(root);
 root.addView(txt("محاكي تدريب طلباتي",25,-1,true),lp(-1,-2));root.addView(txt("تدريب مستقل على قبول الطلب وإدخال الرقم 1–9",14,0xffbfc3ca,false),lp(-1,-2));
 status=txt("اضغط موافق لبدء التدريب",14,0xffcccccc,false);root.addView(status,lp(-1,48));
 order=col();order.setPadding(12,14,12,14);order.setBackground(shape(0xff20242a,24));root.addView(order,lp(-1,-2));
 order.addView(txt("طلب جديد",14,0xffcccccc,false),lp(-1,-2));price=txt("—",30,-1,true);order.addView(price,lp(-1,-2));Button accept=new Button(this);accept.setText("موافق");order.addView(accept,lp(-1,58));accept.setOnClickListener(v->startRound());
 entry=col();entry.setPadding(12,12,12,12);entry.setBackground(shape(0xff171a1f,22));LinearLayout.LayoutParams ep=lp(-1,-2);ep.topMargin=12;root.addView(entry,ep);
 entry.addView(txt("الرقم المطلوب",14,0xffcccccc,false),lp(-1,-2));word=txt("—",42,0xff111111,true);word.setBackground(shape(-1,18));entry.addView(word,lp(-1,94));
 input=new EditText(this);input.setSingleLine(true);input.setInputType(2);input.setTextSize(22);input.setGravity(17);input.setHint("أدخل الرقم 1–9");input.setTextColor(-1);input.setBackground(shape(0xff292e36,14));entry.addView(input,lp(-1,54));
 Button submit=new Button(this);submit.setText("تأكيد الرقم");entry.addView(submit,lp(-1,52));submit.setOnClickListener(v->check());
 LinearLayout stats=new LinearLayout(this);root.addView(stats,lp(-1,-2));last=stat(stats,"آخر زمن");avg=stat(stats,"المتوسط");err=stat(stats,"الأخطاء");
 Button restart=new Button(this);restart.setText("إعادة التدريب");root.addView(restart,lp(-1,50));restart.setOnClickListener(v->showOrder());entry.setVisibility(8);showOrder();}
 TextView stat(LinearLayout parent,String label){LinearLayout b=col();b.setGravity(17);b.setBackground(shape(0xff171a1f,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(3,10,3,10);parent.addView(b,p);b.addView(txt(label,12,0xffcccccc,false));TextView v=txt("—",15,-1,true);b.addView(v);return v;}
 void showOrder(){active=false;order.setVisibility(0);entry.setVisibility(8);price.setText((3+r.nextInt(25))+".000 د.ع");status.setText("طلب جديد جاهز للتدريب");}
 void startRound(){target=r.nextInt(9);word.setText(words[target]);input.setText("");order.setVisibility(8);entry.setVisibility(0);status.setText("أدخل الرقم الذي تمثله الكلمة");started=SystemClock.elapsedRealtime();active=true;}
 void check(){if(!active){status.setText("اضغط موافق أولًا");return;}String s=input.getText().toString().trim();if(s.isEmpty()){status.setText("أدخل رقمًا أولًا");return;}if(!s.equals(""+(target+1))){errors++;err.setText(""+errors);input.setText("");status.setText("خطأ، حاول مرة أخرى");return;}long ms=SystemClock.elapsedRealtime()-started;times.add(ms);if(times.size()>30)times.remove(0);long sum=0;for(long n:times)sum+=n;last.setText(ms+" ms");avg.setText((sum/times.size())+" ms");active=false;((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);input.setText("");status.setText("صحيح ✓ أحسنت");showOrder();}
}