# TalabateyReplica

نسخة تدريبية مستقلة مستوحاة من تجربة شاشة طلب السائق.

## البناء على AndroidIDE

هذا المشروع مضبوط ليتوافق مع Gradle 6.1.1 وJava 8.

من Terminal داخل مجلد المشروع شغّل:

    gradle assembleDebug

بعد نجاح البناء ستجد APK في:

    app/build/outputs/apk/debug/app-debug.apk

لا تحتاج إلى `./gradlew` لأن AndroidIDE عندك يوفر Gradle 6.1.1 مباشرة.

إذا ظهر خطأ متعلقًا بـ `compileSdkVersion 35` فهذا يعني أن Android SDK 35 غير مثبت في AndroidIDE؛ عندها استخدم رقم منصة SDK المثبتة لديك بدل 35 في `app/build.gradle`.
