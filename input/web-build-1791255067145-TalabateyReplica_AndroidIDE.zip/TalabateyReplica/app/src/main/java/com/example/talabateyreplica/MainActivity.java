package com.example.talabateyreplica;

import android.app.*;import android.os.*;import android.graphics.Color;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.content.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout root, orderCard, numRow; EditText number; TextView required; Random random=new Random(); int target=1;
  int red=Color.rgb(229,28,35), dark=Color.rgb(34,34,34), muted=Color.rgb(117,117,117);
  TextView tv(String s,float sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(dark); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(dp(14),dp(7),dp(14),dp(7)); return t; }
  int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
  GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp((int)r));return g;}
  Button btn(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(16);b.setAllCaps(false);b.setBackground(bg(color,8));b.setPadding(dp(8),0,dp(8),0);return b;}
  @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
  void showHome(){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(244,244,244));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
    // Header
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(8),dp(8),dp(8),dp(8));header.setBackgroundColor(Color.WHITE);
    TextView menu=tv("☰",27);header.addView(menu,new LinearLayout.LayoutParams(dp(52),dp(52)));TextView title=tv("طلباتي سواق",20);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);header.addView(title,new LinearLayout.LayoutParams(0,dp(52),1));TextView status=tv("متوفر",15);status.setTextColor(Color.rgb(30,140,70));status.setGravity(Gravity.CENTER);header.addView(status,new LinearLayout.LayoutParams(dp(70),dp(52)));root.addView(header);
    // map area placeholder
    FrameLayout map=new FrameLayout(this);map.setBackgroundColor(Color.rgb(226,230,232));TextView mapText=tv("الخريطة",18);mapText.setTextColor(muted);mapText.setGravity(Gravity.CENTER);map.addView(mapText,new FrameLayout.LayoutParams(-1,-1));root.addView(map,new LinearLayout.LayoutParams(-1,0,1));
    orderCard=new LinearLayout(this);orderCard.setOrientation(LinearLayout.VERTICAL);orderCard.setPadding(dp(14),dp(12),dp(14),dp(12));orderCard.setBackground(bg(Color.WHITE,16));
    TextView available=tv("طلب متوفر",18);available.setTypeface(null,1);available.setTextColor(red);orderCard.addView(available);
    TextView info=tv("طلب توصيل زبون\nرقم الطلب: 123456\nالمطعم: مطعم تجريبي\nالمسافة: 2.4 كم",15);orderCard.addView(info);
    TextView hint=tv("للمتابعة ، أدخل الرقم",15);hint.setTextColor(muted);orderCard.addView(hint);
    numRow=new LinearLayout(this);numRow.setGravity(Gravity.CENTER_VERTICAL);numRow.setPadding(0,dp(5),0,dp(5));
    number=new EditText(this);number.setInputType(2);number.setTextSize(22);number.setGravity(Gravity.CENTER);number.setSingleLine(true);number.setBackground(bg(Color.rgb(248,248,248),8));numRow.addView(number,new LinearLayout.LayoutParams(0,dp(55),1));
    required=tv("الرقم المطلوب: 1",16);required.setGravity(Gravity.CENTER);numRow.addView(required,new LinearLayout.LayoutParams(dp(160),dp(55)));orderCard.addView(numRow);
    Button accept=btn("قبول الطلب",red);orderCard.addView(accept,new LinearLayout.LayoutParams(-1,dp(52)));
    Button reject=btn("رفض الطلب",Color.DKGRAY);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(48));rp.topMargin=dp(7);orderCard.addView(reject,rp);
    root.addView(orderCard,new LinearLayout.LayoutParams(-1,dp(300)));
    setContentView(root); newTarget();
    accept.setOnClickListener(v->{if(number.getText().toString().equals(String.valueOf(target))){Toast.makeText(this,"تم قبول الطلب",Toast.LENGTH_SHORT).show();newTarget();number.setText("");}else{number.setError("الرقم غير صحيح");}});
    reject.setOnClickListener(v->{Toast.makeText(this,"تم رفض الطلب",Toast.LENGTH_SHORT).show();newTarget();number.setText("");});
    menu.setOnClickListener(v->Toast.makeText(this,"القائمة",Toast.LENGTH_SHORT).show());
  }
  void newTarget(){target=1+random.nextInt(9);required.setText("الرقم المطلوب: "+target);}
}
