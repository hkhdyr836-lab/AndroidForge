package com.example.talabateyreplica;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.Random;

public class MainActivity extends Activity {
    private final Random random = new Random();
    private int target;
    private EditText input;
    private TextView targetView;
    private LinearLayout root;
    private int red = Color.rgb(220, 35, 42);
    private int bg = Color.rgb(245, 246, 247);
    private int text = Color.rgb(35, 35, 35);
    private int gray = Color.rgb(110, 110, 110);

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView label(String s, float size) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(text);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private TextView centered(String s, float size) {
        TextView v = label(s, size);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(17);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(color, 10));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        buildScreen();
    }

    private void buildScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // Top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(7), dp(8), dp(7));
        top.setBackgroundColor(Color.WHITE);

        TextView menu = centered("☰", 25);
        top.addView(menu, new LinearLayout.LayoutParams(dp(50), dp(50)));

        TextView title = centered("طلباتي سواق", 20);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(50), 1));

        TextView online = centered("● متوفر", 14);
        online.setTextColor(Color.rgb(28, 145, 75));
        top.addView(online, new LinearLayout.LayoutParams(dp(82), dp(50)));
        root.addView(top);

        // Map placeholder
        FrameLayout map = new FrameLayout(this);
        map.setBackgroundColor(Color.rgb(224, 228, 230));
        TextView mapText = centered("الخريطة", 18);
        mapText.setTextColor(Color.rgb(135, 140, 143));
        map.addView(mapText, new FrameLayout.LayoutParams(-1, -1));
        root.addView(map, new LinearLayout.LayoutParams(-1, 0, 1));

        // Order panel
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(14), dp(16), dp(14));
        panel.setBackground(rounded(Color.WHITE, 18));

        TextView available = label("طلب توصيل جديد", 19);
        available.setTextColor(red);
        available.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        panel.addView(available, new LinearLayout.LayoutParams(-1, dp(32)));

        TextView details = label("رقم الطلب: 123456\nالمطعم: مطعم تجريبي\nالمسافة: 2.4 كم", 15);
        details.setLineSpacing(0, 1.15f);
        panel.addView(details, new LinearLayout.LayoutParams(-1, dp(82)));

        TextView instruction = centered("أدخل الرقم الظاهر لقبول الطلب", 15);
        instruction.setTextColor(gray);
        panel.addView(instruction, new LinearLayout.LayoutParams(-1, dp(34)));

        LinearLayout codeRow = new LinearLayout(this);
        codeRow.setGravity(Gravity.CENTER_VERTICAL);
        codeRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        targetView = centered("1", 27);
        targetView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        targetView.setTextColor(red);
        targetView.setBackground(rounded(Color.rgb(255, 242, 242), 12));
        codeRow.addView(targetView, new LinearLayout.LayoutParams(dp(86), dp(60)));

        input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setTextSize(24);
        input.setGravity(Gravity.CENTER);
        input.setTextColor(text);
        input.setHint("اكتب الرقم");
        input.setHintTextColor(Color.rgb(170, 170, 170));
        input.setBackground(rounded(Color.rgb(248, 248, 248), 12));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, dp(60), 1);
        ip.setMargins(dp(10), 0, 0, 0);
        codeRow.addView(input, ip);
        panel.addView(codeRow, new LinearLayout.LayoutParams(-1, dp(70)));

        TextView targetHint = centered("الرقم المطلوب", 13);
        targetHint.setTextColor(gray);
        panel.addView(targetHint, new LinearLayout.LayoutParams(-1, dp(24)));

        Button accept = button("قبول الطلب", red);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(54));
        ap.topMargin = dp(5);
        panel.addView(accept, ap);

        Button reject = button("رفض الطلب", Color.rgb(75, 75, 75));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(46));
        rp.topMargin = dp(7);
        panel.addView(reject, rp);

        root.addView(panel, new LinearLayout.LayoutParams(-1, dp(335)));
        setContentView(root);
        nextOrder(false);

        accept.setOnClickListener(v -> {
            String entered = input.getText().toString().trim();
            if (entered.equals(String.valueOf(target))) {
                Toast.makeText(this, "تم قبول الطلب", Toast.LENGTH_SHORT).show();
                nextOrder(true);
            } else {
                input.setError("الرقم غير صحيح");
                input.requestFocus();
            }
        });

        reject.setOnClickListener(v -> {
            Toast.makeText(this, "تم رفض الطلب", Toast.LENGTH_SHORT).show();
            nextOrder(true);
        });

        menu.setOnClickListener(v -> Toast.makeText(this, "القائمة", Toast.LENGTH_SHORT).show());
    }

    private void nextOrder(boolean clear) {
        target = 1 + random.nextInt(9);
        targetView.setText(String.valueOf(target));
        if (clear) input.setText("");
        input.clearFocus();
        input.postDelayed(() -> {
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }, 180);
    }
}
